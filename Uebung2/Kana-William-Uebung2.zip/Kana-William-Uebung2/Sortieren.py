import sys

#name_1= sys.argv[1]
#name_2= sys.argv[2]
#name_3= sys.argv[3]

theList= [sys.argv[1],sys.argv[2],sys.argv[3]]

# each line one res
for br in sorted(theList):
  print(br)
