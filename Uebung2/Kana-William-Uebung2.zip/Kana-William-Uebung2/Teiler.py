
zahl=int(input(("enter your number ")))

i=1;

while zahl > i:
    if ( ( zahl % i)== 0 ):
        print(i)
    i=i+1



"""
i=1;
liste_number= list()

while zahl > i:
    if ( ( zahl % i)== 0 ):
        print(i)
        liste_number.append(i)
    i=i+1
print(liste_number)

"""

