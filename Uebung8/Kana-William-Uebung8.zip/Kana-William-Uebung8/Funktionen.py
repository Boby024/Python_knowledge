from nutzereingaben import eingaben

eingaben()



