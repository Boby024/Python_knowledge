
zahl= int(input("enter your number for the multiplication : "))

for i in range( 1,11):
    print(abs(zahl)*i)