
zahl= float(input("enter your point number: "))
speicher=0
result=0;
while(zahl >speicher):
    result += zahl
    zahl= float(input("enter your point number: "))
print("Summe ist :  ",result)
