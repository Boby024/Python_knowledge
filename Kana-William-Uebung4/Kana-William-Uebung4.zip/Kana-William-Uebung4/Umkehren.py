
list_Array=list()
for erste in range(1,31 ):
    if(erste%3 ==0):
        list_Array.append(erste)

list_Array.sort( reverse = True )

for first in list_Array:
    print(first)

