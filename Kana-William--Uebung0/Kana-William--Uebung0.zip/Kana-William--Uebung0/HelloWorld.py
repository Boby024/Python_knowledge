
name= "William"
print("Hallo " ,name)
